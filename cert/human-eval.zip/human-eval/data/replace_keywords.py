import json
import os
import gzip
import sys
import random
import ipdb

import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--base_dir', type=str, default="/home/v-dazan/Desktop/zandaoguang/human-eval/data")
    parser.add_argument('--library_name', type=str, default="numpy", choices=["pandas", "numpy"])

    args = parser.parse_args()
    print(f"{args = }")

    library_path = os.path.join(args.base_dir, f"real_{args.library_name}_eval_v2_api_n.jsonl.gz")
    output_key_word_path = os.path.join(args.base_dir, f"{args.library_name}_keywords.jsonl")

    library_reader = gzip.open(library_path, "rb")
    output_key_word_writer = open(output_key_word_path, "a+")

    library_key_words = dict()

    for line in library_reader:
        line_decoded = line.decode("utf-8")
        line_dict = json.loads(line_decoded)
        # print(line_dict.keys())
        # print(line_dict)
        task_id = line_dict["task_id"]
        prompt = line_dict["prompt"]
        canonical_solution = line_dict["canonical_solution"][0]

        print("---"*25)
        print(f"{task_id = }")
        print(prompt)
        print(canonical_solution)
        print("---"*25)

        key_words_str = input("请输入这个问题的关键字: old_key:new_key;old_key2:new_key2;...\n")
        
        if key_words_str == "no":
            continue

        try:
            for key_word in key_words_str.split(";"):
                old_key, new_key = key_word.split(":")
                if library_key_words.get(old_key) is None:
                    library_key_words[old_key] = new_key
                    print(f"{old_key}:{new_key}已经保存下来啦！")
                else:
                    print(f"{old_key} 已经存在了")
        except Exception as e:
            print(e)
            key_words_str = input("请重新输入这个问题的关键字: old_key:new_key;old_key2:new_key2;...\n")
            for key_word in key_words_str.split(";"):
                old_key, new_key = key_word.split(":")
                if library_key_words.get(old_key) is None:
                    library_key_words[old_key] = new_key
                    print(f"{old_key}:{new_key}已经保存下来啦！")
                else:
                    print(f"{old_key} 已经存在了")

        # break

    output_key_word_writer.write(json.dumps(library_key_words))
    library_reader.close()
    output_key_word_writer.close()
    print("All Done!")
