# PandasEval and NumpyEval Benchmarks 

The setup process can be referred to [HumanEval](https://github.com/openai/human-eval)

The changes compared to HumanEval include the following parts.
* Added PandasEval.json.gz and NumpyEval.json.gz to the data folder.
* Modified human_eval/data.py and human_eval/execution.py to better evaluate PandasEval and NumpyEval.